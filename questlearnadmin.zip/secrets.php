<?php
// secrets.php
// DO NOT COMMIT THIS FILE TO GITHUB! 
// This file is ignored via .gitignore

// Groq API Key for the AI Curriculum Generator
define('GROQ_API_KEY_MAIN', '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');

// Groq API Key for the AI Performance Analytics 
define('GROQ_API_KEY_ANALYTICS', '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');

// Cloudinary API Credentials
define('CLOUDINARY_CLOUD_NAME', 'dghen22jr');
define('CLOUDINARY_API_KEY', '589577445523121');
define('CLOUDINARY_API_SECRET', 'QN1Z4YnMTf2AGxTOzJ1ilVOTWb4');
?>
